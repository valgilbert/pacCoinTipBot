#!/bin/bash -e

sudo apt-get update
sudo apt-get install python3 python3-pip
sudo apt-get install python3-setuptools

sudo pip3 install python-telegram-bot --upgrade
sudo pip3 install discord.py --upgrade
sudo pip3 install python-bitcoinrpc --upgrade
sudo pip3 install asyncio --upgrade
sudo pip3 install pytz
sudo pip3 install config-reader

sudo mkdir -p /opt/pacCoinTipBot

sudo cp ~/pacCoinTipBot/pacCoinDiscordTipBot /usr/local/bin/pacCoinDiscordTipBot
sudo cp ~/pacCoinTipBot/pacCoinDiscordTipBot.py /opt/pacCoinTipBot/pacCoinDiscordTipBot.py
sudo cp ~/pacCoinTipBot/pacCoinTelegramTipBot /usr/local/bin/pacCoinTelegramTipBot
sudo cp ~/pacCoinTipBot/pacCoinTelegramTipBot.py /opt/pacCoinTipBot/pacCoinTelegramTipBot.py
sudo cp ~/pacCoinTipBot/pickledb.py /opt/pacCoinTipBot/pickledb.py
sudo cp ~/pacCoinTipBot/pacCoinDiscordTipBot.service /lib/systemd/system/pacCoinDiscordTipBot.service
sudo cp ~/pacCoinTipBot/pacCoinTelegramTipBot.service /lib/systemd/system/pacCoinTelegramTipBot.service

sudo systemctl daemon-reload
sudo systemctl enable pacCoinDiscordTipBot
sudo systemctl enable pacCoinTelegramTipBot

rm ~/pacCoinTipBot/pacCoinDiscordTipBot*
rm ~/pacCoinTipBot/pacCoinTelegramTipBot*
rm ~/pacCoinTipBot/pickledb.py
rm ~/pacCoinTipBot/install_bot.sh

echo "Bot Installation DONE!!"
