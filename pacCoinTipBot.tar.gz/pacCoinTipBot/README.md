## PacCoin crypto currency TipBot for Telegram & Discord

## Server Requirements
```
Ubuntu 16.04
```

## Dependencies:
```bash
sudo apt-get update
sudo apt-get install git
```

## Install:
```bash
git clone https://github.com/valgilbert/PacCoinTipBot
bash ~/pacCoinTipBot/install_wallet.sh
bash ~/pacCoinTipBot/install_bot.sh
```

## Configuration:
```
Update bot config file accordingly:
~/pacCoinTipBot/pacCoinTipbotConfig.json
{
    "BOTNAME":"PAC-BOT", // bot name
    "BOTUUID":"436874104424103937", // bot User ID
    "BOTCHID":"470183230121967615", // Channel Id i.e taken from this url https://discordapp.com/channels/470183165395337217/470183230121967615
    "TOKEN":"NDM2ODc0MTA0NDI0MTAzOTM4.DjSkUg.gb4-TDKx-usxqvC9l8u-DTGRLHM", // Bot token created in https://discordapp.com/developers/applications/me
    "LOG_FILE": "/home/{user}/pacCoinTipBot/pac-bot.log", // log file
    "RPC_USERNAME": "pacbot", // rpc username from paccoin.conf
    "RPC_PASSWORD": "pacbot123", // rpc password from paccoin.conf
    "RPC_IP": "127.0.0.1", // rpc ip from paccoin.conf
    "RPC_PORT": "27111" // rpc port from paccoin.conf
}
```

## Usage:
```bash
pacCoinDiscordTipBot start
pacCoinDiscordTipBot stop
pacCoinDiscordTipBot status
pacCoinDiscordTipBot restart
```

## @Depracted(Do not use) SYSTEMD:
```bash
Telegram TipBOT

sudo systemctl enable pacCoinTelegramTipBot    (to enable TipBot at boot)
sudo systemctl start pacCoinTelegramTipBot     (to start TipBot)
sudo systemctl stop pacCoinTelegramTipBot      (to stop TipBot)
sudo systemctl restart pacCoinTelegramTipBot   (to restart TipBot)
sudo systemctl status pacCoinTelegramTipBot    (to view status of TipBot process)

Discord TipBOT

sudo systemctl enable pacCoinDiscordTipBot    (to enable TipBot at boot)
sudo systemctl start pacCoinDiscordTipBot     (to start TipBot)
sudo systemctl stop pacCoinDiscordTipBot      (to stop TipBot)
sudo systemctl restart pacCoinDiscordTipBot   (to restart TipBot)
sudo systemctl status pacCoinDiscordTipBot    (to view status of TipBot process)
```

## Telegram
  Setup a bot with the user @BotFather through PM on Telegram, after going through a setup you will be given a bot token. Edit the pacCoinTelegramTipBot.py file and replace the parameter '____TOKEN____' with the one you just recieved.
  Initiate the bot by inviting it to a chat or via PM

## Discord
  Create new BOT by accessing this url (https://discordapp.com/developers/applications/me), after going through setup you will be given a BOT token. Edit the pacCoinDiscordTipBot.py file and replace the parameter '____TOKEN____' with the one you just recieved.


  Setting up the bot as so still leaves the wallet unencrypted, so please go to extra measures to provide extra security. Make sure to have a good firewall on whatever device/droplet you run it on.

Please fork the code, happy tipping!
