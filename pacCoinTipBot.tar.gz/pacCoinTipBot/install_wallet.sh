#!/bin/bash -e

wget https://github.com/PACCommunity/PAC/releases/download/v0.12.3.1/PAC-v0.12.3.1-linux-x86_64.tar.gz
mkdir ~/paccoin
mkdir ~/.paccoincore
mv ~/pacCoinTipBot/paccoin.conf ~/.paccoincore/paccoin.conf
tar -xzvf PAC-v0.12.3.1-linux-x86_64.tar.gz -C ~/paccoin
rm PAC-v0.12.3.1-linux-x86_64.tar.gz
~/paccoin/paccoind &
rm ~/pacCoinTipBot/install_wallet.sh

echo "Wallet installation DONE!!"
